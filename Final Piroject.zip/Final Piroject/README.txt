This is the final project of Luke and Ariel
It is an enhancement of the projects we have been building on throughout
the course and are fairly proud of what we put together despite adversity.
The game controls using the bread board. I (Luke) had a hard time finding the exact right
resistors and such for the project in the fritzing application, it may be somewhat incorrect.
I also couldn't find our chip, so I pinned it directly to the output instead. It is how mine is set up anyway.
Have a nice day. :)