###########################################################################################
# Name: Luke/Ariel
# Date: 11/12/2018
# Description: This is an even further extended version of the room adventure project,
# the game now plays music from the speakers and has physical controls that can be used
# to navigate.
###########################################################################################
from Tkinter import*
import RPi.GPIO as GPIO
import pygame
import time

# Pins definitions
btn_pin1 = 4
btn_pin2 = 18
btn_pin3 = 23
btn_pin4 = 25
red = 12
green = 13
buzzer_pin = 21


# Set up pins
GPIO.setmode(GPIO.BCM)
GPIO.setup(btn_pin1, GPIO.IN)
GPIO.setup(btn_pin2, GPIO.IN)
GPIO.setup(btn_pin3, GPIO.IN)
GPIO.setup(btn_pin4, GPIO.IN)
GPIO.setup(red, GPIO.OUT)
GPIO.setup(green, GPIO.OUT)
GPIO.setup(buzzer_pin, GPIO.OUT)

pygame.init()
pygame.mixer.init()
song = pygame.mixer.music.load('music.wav')
pygame.mixer.music.play(-1)



def makePhrase(a):
    words = a
    return



#Sets up the class "Room" referenced throughout the code.
class Room(object):

        # the constructor
        def __init__(self, name, image, song):
                # rooms have a name, exits (e.g., south), exit locations (e.g., to the south is room n),
                # items (e.g., table), item descriptions (for each item), and grabbables (things that can
                # be taken into inventory)
                self.name = name
                self.image = image
                self.exits = {}
                self.items = {}
                self.grabbables = []
                self.song = song



        # getters and setters for the instance variables
        @property
        def name(self):
                return self._name

        @name.setter
        def name(self, value):
                self._name = value

        @property
        def image(self):
                return self._image

        @image.setter
        def image(self, value):
                self._image = value

        @property
        def sound(self):
                return self._name

        @name.setter
        def sound(self, value):
                self._name = value

        @property
        def exits(self):
                return self._exits

        @exits.setter
        def exits(self, value):
                self._exits = value

        @property
        def items(self):
                return self._items

        @items.setter
        def items(self, value):
                self._items = value

        @property
        def grabbables(self):
                return self._grabbables

        @grabbables.setter
        def grabbables(self, value):
                self._grabbables = value

        def addExit(self, exit, room):
                # append the exit and room to the appropriate dictionary
                self._exits[exit] = room

        # adds an item to the room
        # the item is a string (e.g., table)
        # the desc is a string that describes the item (e.g., it is made of wood)
        def addItem(self, item, desc):
                # append the item and description to the appropriate dictionary
                self._items[item] = desc

        # adds a grabbable item to the room
        # the item is a string (e.g., key)
        def addGrabbable(self, item, desc = ""):
                # append the item to the list
                self._grabbables.append(item)

        # removes a grabbable item from the room
        # the item is a string (e.g., key)
        def delGrabbable(self, item):
                # remove the item from the list
                self._grabbables.remove(item)


        # returns a string description of the room
        def __str__(self):
                # first, the room name
                s = "You are in {}.\n".format(self.name)

                # next, the items in the room
                s += "You see: "
                for item in self.items.keys():
                        s += item + " "
                s += "\n"

                # next, the exits from the room
                s += "Exits: "
                for exit in self.exits.keys():
                        s += exit + " "

                return s


#Constructs the Game Class which sets up logic and populates the rooms
class Game(Frame):
    global countPress
    global allowAction
    def __init__(self, parent):
        Frame.__init__(self, parent)
    # Check on button state
    def poll(self):

        global window
        global btn_pin
        global canvas
        global circle

        if self.allowAction:
            # Make
            if GPIO.input(btn_pin1):
                print"East"
                self.allowAction = False
                self.checkAction("go east")
            if GPIO.input(btn_pin2):
                print"West"
                self.checkAction("go west")
                self.allowAction = False
            if GPIO.input(btn_pin3):
                print"North"
                self.checkAction("go north")
                self.allowAction = False
            if GPIO.input(btn_pin4):
                print"South"
                self.checkAction("go south")
                self.allowAction = False
            else:
                print "Null"
        else:
            self.countPress += 1
            if(self.countPress > 40):
                self.allowAction = True
                self.countPress = 0

        # Schedule the poll() function for another 10 ms from now
        window.after(10, self.poll)

    #Each room has an initial creation, to be modified later.
    def createRooms(self):
        r1 = Room("Room 1", "room1.gif","Song1")
        r2 = Room("Room 2", "room2.gif","Song2")
        r3 = Room("Room 3", "room3.gif","Song3")
        r4 = Room("Room 4", "room4.gif","Song4")
        r5 = Room("Room 5", "room5.gif","Song5")
        r6 = Room("Room 6", "room6.gif","Song6")
        r7 = Room("Room 7", "room7.gif","Song7")
        r8 = Room("Room 8", "room8.gif","Song8")
        r9 = Room("Room 9", "room9.gif","Song9")


        

        # add exits to room 1
        r1.addExit("east", r2)  # -> to the east of room 1 is room 2
        r1.addExit("south", r4)
        # add grabbables to room 1
        r1.addGrabbable("cheese")
        # add items to room 1
        r1.addItem("stove", "I think someone is making soup? I hope they come turn the stove off.")
        r1.addItem("table", "It is made of oak. There is a knife and some partially sliced cheese.")
        r1.addItem("window", "It looks like there is a lot of ""outside"" outside.")


        # add exits to room 2
        r2.addExit("west", r1)
        r2.addExit("south", r5)
        r2.addExit("east", r3)
        # add items to room 2
        r2.addItem("rug", "It is nice and Indian. Seems like a job for anyone else at all.")
        r2.addItem("fireplace", "A fire is burning. Who started it? A book is sitting on top. It is called ""book"".")
        r2.addGrabbable("book")

        # add grabbables to room 4
        r3.addExit("west", r2)
        r3.addExit("south", r6)
        r3.addGrabbable("cocaine")
        # add items to room 4
        r3.addItem("couch", "There is a blue couch here that looks like no one has sat in it for at least 5 whole minutes.")
        r3.addItem("pictures", "There is an assortment of pictures on the wall. Or maybe it is a window, not sure.... whoever drew that center image could have made that more clear.")
        r3.addItem("carpet", "It is the same color as the couch... or is it?.")

        # add exits to room 4

        # add grabbables to room 4
        r4.addExit("north", r1)
        r4.addExit("east", r5)
        r4.addExit("south", r7)
        r4.addGrabbable("supermario64")
        # add items to room 4
        r4.addItem("beanbag", "It is as ""in the corner"" as it is an outdated, but incredibly comfortable means to sit.")
        r4.addItem("N64", "There is an N64 in the middle of the floor. Rad.")
        r4.addItem("TV", "The TV looks like it... is a TV.")

        # Improving Room 5
        r5.addExit("south", r8)
        r5.addExit("west", r4)
        r5.addExit("east", r6)
        r5.addExit("north", r2)
        # Add items to Room 5
        r5.addItem("cat", "It is peacfully sleeping in its cat bed. It does look like the kind of cat that would chew up all the wires to this very Rasberry Pi. It is wearing a collar, you could try to take it.")
        r5.addItem("Scratching-Post", "It's all in the name. It is a post. You scratch it. Are you satisfied?")
        r5.addItem("Litter-Box", "A great place to ""pan for Gold"".")
        # add grabbables to room 5
        r5.addGrabbable("collar")

        # add exits to room 6
        r6.addExit("north", r3)
        r6.addExit("south", r9)
        r6.addExit("west", r5)
        # add items to room 2
        r6.addItem("Rasberry-Pi", "There is a little Rasberry Pi sitting on the desk. It looks like someone spent way too much time the past few days trying to get those stupid direction buttons working. Sad.")
        r6.addItem("dead-plant ", "It's a dead plant... WOW")
        r6.addGrabbable("bread-board")

        #Improving Room 7
        r7.addExit("north", r4)
        r7.addExit("east", r8)
        r7.addGrabbable("ducky")
        # Add items to Room 7
        r7.addItem("bath", "It is a poorly drawn bath tub! I bet the artist was running low on time! What a loser!!!")
        r7.addItem("sink", "It is a sink that completely defies lighting conventions! How does it get away with not being shaded at all like that? was that on purpose? Just for this joke? This room looks awful.")

        #Improving Room 8
        r8.addExit("west", r7)
        r8.addExit("north", r5)
        r8.addExit("east", r9)
        # Add items to Room 8
        r8.addItem("bike", "There is a bike... woohoo.")
        r8.addItem("key-holder", "You want to take that key? Go for it.")
        # add grabbables to room 8
        r8.addGrabbable("key")

        #Improving Room 9
        r9.addExit("north", r6)
        r9.addExit("west", r8)
        # Add items to Room 9
        r9.addItem("bed", "There is a luxurious bed against the right wall. It is a bed and it is luxurious. A bed that's luxurious. One of those pillows might be worth some points.")
        r9.addItem("red?", "This cotaing of red, is most likely not at all blood. That's a ridiculous thing to think.. why would you say that? You weirdo.....  Geez, that's on you. Don't pin your weird mind on me, I'm just the pi game.")
        # add grabbables to room 9
        r9.addGrabbable("pillow")

        # set room 5 as the current room at the beginning of the game
        Game.currentRoom = r5
        Game.inventory = []

        #Sets up the variables and locations of widgets and labels that occupy the GUI space.
    def setupGUI(self):
        self.pack(fill=BOTH, expand=1)

        #Entry field for the user.
        Game.player_input = Entry(self, bg="white")

        #Locks input to the above input field
        Game.player_input.bind("<Return>", self.process)
        Game.player_input.pack(side=BOTTOM, fill=X)
        Game.player_input.focus()

        #Sets the image to nothing by default only to be immediately replaced.
        img = None
        Game.image = Label(self, width=WIDTH / 2, image=img)
        Game.image.image = img

        #Tells the GUI where and how to place the room images.
        Game.image.pack(side=LEFT, fill=Y)
        Game.image.pack_propagate(False)

        #Dicates the frame of the text box full of stats
        text_frame = Frame(self, width=WIDTH / 2)

        #Player input is disabled for the status
        Game.text = Text(text_frame, bg="lightgrey", state=DISABLED)
        Game.text.pack(fill=Y, expand=1)
        text_frame.pack(side=RIGHT, fill=Y)
        text_frame.pack_propagate(False)



    #Tells the room how to access the image it needs
    def setRoomImage(self):
        if(Game.currentRoom == None):
            Game.img = PhotoImage(file="skull.gif")
        else:
            Game.img = PhotoImage(file=Game.currentRoom.image)

        Game.image.config(image=Game.img)
        Game.image.image = Game.img

    #Deletes the last thing and puts something new in stats
    def setStatus(self, status):
        Game.text.config(state=NORMAL)
        Game.text.delete("1.0", END)

        # Player is dead if they are outside of any room.
        if (Game.currentRoom == None):
            Game.text.insert(END, "You are dead looser.")
            #Game.text.insert("Score {}/10").format(score)
        else:
            #If the player successfully makes it into the next room it shows their stats
            Game.text.insert(END, str(Game.currentRoom) + "\nYou are carrying: " + str(Game.inventory) + "\n\n" + status + "\nScore:"+ str(score) + "/9")

        Game.text.config(state = DISABLED)                                  

    #Calls all of the above functions
    def play(self):
        self.createRooms()
        self.setupGUI()
        self.setRoomImage()
        self.setStatus("")

    
    #Teaches the program how to interpret nouns and verbs
    def process(self, event):
        action = Game.player_input.get()
        action = action.lower()
        response = "I don't understand. Try verb noun. Valid verbs are go, look, and take"
        if (action == "quit" or action == "exit" or action == "bye" or action == "sionara!"):
                GPIO.cleanup()
                exit(0)

        #Removes the last thing the player entered when they die
        if (Game.currentRoom == None):
                Game.player_input.delete(0, END)
                return

        #breaks words apart to be read by the program
        self.checkAction(action);

    def checkAction(self, action):
        global score
        words = action.split()
        if (len(words) == 2):
                #isolate the verb and noun
                verb = words[0]
                noun = words[1]
                
                if (verb == "go"):
                        response = "Invalid exit."

                        if (noun in Game.currentRoom.exits):
                                Game.currentRoom = Game.currentRoom.exits[noun]
                                response = "Room changed."

                elif (verb == "look"):
                        response = "I don't see that item."

                        if (noun in Game.currentRoom.items):
                                response = Game.currentRoom.items[noun]

                #the verb is : take
                elif (verb == "take"):
                        response = "I don't see that item."
                        for grabbable in Game.currentRoom.grabbables:
                                #check for valid grabbable item is found
                                if (noun == grabbable):
                                        #add the grabbable item to inventory.
                                        Game.inventory.append(grabbable)
                                        Game.currentRoom.delGrabbable(grabbable)
                                        score += 1
                                        response = "Item grabbed."
                                        p.start(100)
                                        time.sleep(1)
                                        p.stop()
                                        break

        self.setStatus(response)
        self.setRoomImage()
        Game.player_input.delete(0, END)

#Main program
WIDTH = 800
HEIGHT = 600
score = 0
window = Tk()
window.title("Room Adventure Revolutions")
g = Game(window)
g.play()
g.countPress = 0
g.allowAction = True

 
window.after(10, g.poll)
window.mainloop()
